import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const FormSection = () => {
  return (
    <div className="container my-5">
      <div className="row align-items-center">
        {/* First Div - Image */}
        <div className="col-md-6 text-center">
          <img 
            src={`${process.env.PUBLIC_URL}/Form1.png`} 
            alt="Your Image" 
            className="img-fluid" 
            style={{ width: '100%', height: 'auto' }} // Adjust the size as needed
          />
        </div>

        {/* Second Div - Contact Form */}
        <div className="col-md-6">
          <h2>Contact Us</h2>
          <form>
            <div className="mb-3">
              <input 
                type="text" 
                className="form-control" 
                placeholder="Name" 
                required 
              />
            </div>
            <div className="mb-3">
              <input 
                type="email" 
                className="form-control" 
                placeholder="Email" 
                required 
              />
            </div>
            <div className="mb-3">
              <input 
                type="tel" 
                className="form-control" 
                placeholder="Phone" 
                required 
              />
            </div>
            <div className="mb-3">
              <textarea 
                className="form-control" 
                rows="4" 
                placeholder="Message" 
                required 
              ></textarea>
            </div>
            <button type="submit" className="btn btn-primary">Send Message</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default FormSection;
