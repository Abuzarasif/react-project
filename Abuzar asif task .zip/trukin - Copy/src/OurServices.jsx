// import React from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';

// const OurServices = () => {
//   return (
//     <div className="container my-5" style={{ width: '70%', textAlign: 'center' }}>
//       {/* Section Heading */}
//       <h6>OUR SERVICES</h6>
//       <h1 className="mb-5">Safe & Reliable Truck Dispatching Solution</h1>

//       {/* Flex container for two main service divs */}
//       <div className="d-flex justify-content-between">
        
//         {/* First Service - Freight Dispatch */}
//         <div 
//           className="d-flex align-items-center" 
//           style={{
//             width: '400px',
//             height: '115px',  // Set both divs to the same height
//             borderRadius: '20px 0px 0px 0px',
//             border: '1px solid #000', // Apply 1px solid border to match both divs
//             gap: '0px',
//             opacity: '1',
//           }}
//         >
//           {/* Image Div with right border */}
//           <div 
//             className="d-flex border-end border-2 pe-3 align-items-center justify-content-center"
//             style={{ width: '70px' }}  // Ensures the image and div are centered
//           >
//             <img
//               src={`${process.env.PUBLIC_URL}/ATruck.png`}
//               alt="Freight Dispatch"
//               className="img-fluid"
//               style={{
//                 width: '70px',
//                 height: '30.59px',  // Set the height of the first image
//               }}
//             />
//           </div>

//           {/* Text content */}
//           <div className="ps-3">
//             <h4
//               style={{
//                 fontFamily: 'Poppins',
//                 fontSize: '20px',
//                 fontWeight: '600',
//                 lineHeight: '30px',
//                 textAlign: 'left',
//               }}
//             >
//               Freight Dispatch
//             </h4>
//             <p>As the best truck dispatching service in the business.</p>
//           </div>
//         </div>

//         {/* Second Service - Freight Brokerage */}
//         <div 
//           className="d-flex align-items-center" 
//           style={{
//             width: '400px',
//             height: '115px',  // Same height for both divs
//             borderRadius: '20px 0px 0px 0px',
//             border: '1px solid #000', // Apply 1px solid border to match both divs
//             gap: '0px',
//             opacity: '1',
//           }}
//         >
//           {/* Image Div with right border */}
//           <div 
//             className="d-flex border-end border-2 pe-3 align-items-center justify-content-center"
//             style={{ width: '71px' }}  // Ensures the image and div are centered
//           >
//             <img
//               src={`${process.env.PUBLIC_URL}/BTruck.png`}
//               alt="Freight Brokerage"
//               className="img-fluid"
//               style={{
//                 width: '71px',
//                 height: '26.46px',  // Set the height of the second image
//               }}
//             />
//           </div>

//           {/* Text content */}
//           <div className="ps-3">
//             <h4
//               style={{
//                 fontFamily: 'Poppins',
//                 fontSize: '20px',
//                 fontWeight: '600',
//                 lineHeight: '30px',
//                 textAlign: 'left',
//               }}
//             >
//               Freight Brokerage
//             </h4>
//             <p>As the best truck dispatching service in the business.</p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default OurServices;


// import React from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';

// const OurServices = () => {
//   return (
//     <div className="container my-5" style={{ width: '70%', textAlign: 'center' }}>
//       {/* Section Heading */}
//       <h6>OUR SERVICES</h6>
//       <h1 className="mb-5">Safe & Reliable Truck Dispatching Solution</h1>

//       {/* Flex container for two main service divs */}
//       <div className="row justify-content-center">
        
//         {/* First Service - Freight Dispatch */}
//         <div 
//           className="col-12 col-md-6 d-flex align-items-center mb-4" 
//           style={{
//             borderRadius: '20px 0px 0px 0px',
//             border: '1px solid #000', // Apply 1px solid border to match both divs
//             opacity: '1',
//             height: '115px',
//           }}
//         >
//           {/* Image Div with right border */}
//           <div 
//             className="d-flex border-end border-2 pe-3 align-items-center justify-content-center"
//             style={{ width: '30%' }}  // Set width to 30%
//           >
//             <img
//               src={`${process.env.PUBLIC_URL}/ATruck.png`}
//               alt="Freight Dispatch"
//               className="img-fluid"
//               style={{
//                 width: '100%', // Adjust to fill the parent div
//                 height: 'auto', // Maintain aspect ratio
//               }}
//             />
//           </div>

//           {/* Text content */}
//           <div className="ps-3" style={{ width: '70%' }}> {/* Set width to 70% */}
//             <h4
//               style={{
//                 fontFamily: 'Poppins',
//                 fontSize: '20px',
//                 fontWeight: '600',
//                 lineHeight: '30px',
//                 textAlign: 'left',
//               }}
//             >
//               Freight Dispatch
//             </h4>
//             <p>As the best truck dispatching service in the business.</p>
//           </div>
//         </div>

//         {/* Second Service - Freight Brokerage */}
//         <div 
//           className="col-12 col-md-6 d-flex align-items-center mb-4" 
//           style={{
//             borderRadius: '20px 0px 0px 0px',
//             border: '1px solid #000', // Apply 1px solid border to match both divs
//             opacity: '1',
//             height: '115px',
//           }}
//         >
//           {/* Image Div with right border */}
//           <div 
//             className="d-flex border-end border-2 pe-3 align-items-center justify-content-center"
//             style={{ width: '30%' }}  // Set width to 30%
//           >
//             <img
//               src={`${process.env.PUBLIC_URL}/BTruck.png`}
//               alt="Freight Brokerage"
//               className="img-fluid"
//               style={{
//                 width: '100%', // Adjust to fill the parent div
//                 height: 'auto', // Maintain aspect ratio
//               }}
//             />
//           </div>

//           {/* Text content */}
//           <div className="ps-3" style={{ width: '70%' }}> {/* Set width to 70% */}
//             <h4
//               style={{
//                 fontFamily: 'Poppins',
//                 fontSize: '20px',
//                 fontWeight: '600',
//                 lineHeight: '30px',
//                 textAlign: 'left',
//               }}
//             >
//               Freight Brokerage
//             </h4>
//             <p>As the best truck dispatching service in the business.</p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default OurServices;



import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const OurServices = () => {
  return (
    <div className="container my-5" style={{ width: '70%', textAlign: 'center' }}>
      {/* Section Heading */}
      <h6>OUR SERVICES</h6>
      <h1 className="mb-5" Style={"Color:#045CB4"}>Safe & Reliable Truck Dispatching Solution</h1>

      {/* Flex container for two main service divs */}
      <div className="row justify-content-center">
        
        {/* First Service - Freight Dispatch */}
        <div 
          className="col-12 col-md-6 d-flex align-items-center mb-4" 
          style={{
            borderRadius: '20px 0px 0px 0px',
            opacity: '1',
            height: '115px',
          }}
        >
          {/* Image Div with right border */}
          <div 
            className="d-flex border-end border-2 pe-3 align-items-center justify-content-center"
            style={{ width: '30%' }}  // Set width to 30%
          >
            <img
              src={`${process.env.PUBLIC_URL}/ATruck.png`}
              alt="Freight Dispatch"
              className="img-fluid"
              style={{
                width: '100%', // Adjust to fill the parent div
                height: 'auto', // Maintain aspect ratio
              }}
            />
          </div>

          {/* Text content */}
          <div className="ps-3" style={{ width: '70%' }}> {/* Set width to 70% */}
            <h4
              style={{
                fontFamily: 'Poppins',
                fontSize: '20px',
                fontWeight: '600',
                lineHeight: '30px',
                textAlign: 'left',
              }}
            >
              Freight Dispatch
            </h4>
            <p style={{ textAlign: 'Justify' }}
       >As the best truck dispatching service in the business.</p>
          </div>
        </div>

        {/* Second Service - Freight Brokerage */}
        <div 
          className="col-12 col-md-6 d-flex align-items-center mb-4" 
          style={{
            borderRadius: '20px 0px 0px 0px',
            opacity: '1',
            height: '115px',
          }}
        >
          {/* Image Div with right border */}
          <div 
            className="d-flex border-end border-2 pe-3 align-items-center justify-content-center"
            style={{ width: '30%' }}  // Set width to 30%
          >
            <img
              src={`${process.env.PUBLIC_URL}/BTruck.png`}
              alt="Freight Brokerage"
              className="img-fluid"
              style={{
                width: '100%', // Adjust to fill the parent div
                height: 'auto', // Maintain aspect ratio
              }}
            />
          </div>

          {/* Text content */}
          <div className="ps-3" style={{ width: '70%' }}> {/* Set width to 70% */}
            <h4
              style={{
                fontFamily: 'Poppins',
                fontSize: '20px',
                fontWeight: '600',
                lineHeight: '30px',
                textAlign: 'left',
              }}
            >
              Freight Brokerage
            </h4>
            <p style={{ textAlign: 'Justify' }}
            >As the best truck dispatching service in the business.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OurServices;
