import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Footer = () => {
  return (
    <div style={{ backgroundColor: '#045CB4', padding: '40px 0' }}>
      <div className="container d-flex justify-content-center text-light">
        <div className="row w-100 align-items-center">
          {/* First Div - Logo and Paragraph */}
          <div className="col-md-4 text-center mb-4">
            <img 
              src={`${process.env.PUBLIC_URL}/MhiTruck.png`} 
              alt="Logo" 
              className="img-fluid mb-3" 
            />
            <p>
              We provide the best truck dispatching services in the industry, ensuring that your transportation needs are met with efficiency and reliability.
            </p>
            <div className="d-flex justify-content-center">
              {/* Logos */}
              <img src={`${process.env.PUBLIC_URL}/Insta.png`} alt="Logo 1" style={{ width: '20px', marginRight: '3rem' }} />
              <img src={`${process.env.PUBLIC_URL}/fb.png`} alt="Logo 2" style={{ width: '20px', marginRight: '3rem' }} />
              <img src={`${process.env.PUBLIC_URL}/Li.png`} alt="Logo 3" style={{ width: '20px' }} />
            </div>
          </div>

          {/* Second Div - Links */}
          <div className="col-md-4 text-center mb-4">

            <h6 Style={"Line-height:1.3rem"} >Blogs</h6>
            <h6 Style={"Line-height:1.3rem"} >Sitemap</h6>
            <h6 Style={"Line-height:1.3rem"} >Privacy Policy</h6>
            <h6 Style={"Line-height:1.3rem"} >Terms & Conditions</h6>
            <h6 Style={"Line-height:1.3rem"} >Sitemap</h6>

          </div>

          {/* Third Div - Additional Links */}
          <div className="col-md-4 text-center mb-4">
            <h6 Style={"Line-height:1.3rem"} >Home</h6>
            <h6 Style={"Line-height:1.3rem"} >Services</h6>
            <h6 Style={"Line-height:1.3rem"} >About Us</h6>
            <h6 Style={"Line-height:1.3rem"} >FAQs</h6>
            <h6 Style={"Line-height:1.3rem"} >Contact Us</h6>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
