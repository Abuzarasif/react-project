import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const ValuesSection = () => {
  return (
    <div className="container my-5">
      {/* Flex Container for Three Divs */}
      <div className="row">
        {/* First Div - Synergy */}
        <div className="col-md-4 mb-4 text-start">
          <img
            src={`${process.env.PUBLIC_URL}/Synergy.png`}
            alt="Synergy Icon"
            className="img-fluid mb-3"
            style={{ width: '27.25px', height: '27.25px' }}
          />
          <h3 Style={"Color:#045CB4"}>Synergy</h3>
          <p>
            At Swift Dispatch Services, we are committed to being the best truck dispatching service in the industry. We firmly believe in harnessing our collective resources and expertise to generate unparalleled levels of efficacy, value, and performance for our esteemed clients. Your success is our mission.
          </p>
        </div>

        {/* Second Div - Transparency */}
        <div className="col-md-4 mb-4 text-start">
          <img
            src={`${process.env.PUBLIC_URL}/Transparency.png`}
            alt="Transparency Icon"
            className="img-fluid mb-3"
            style={{ width: '27.25px', height: '27.25px' }}
          />
          <h3 Style={"Color:#045CB4"}>Transparency</h3>
          <p>
            As the best truck dispatching service in the business, our commitment to our clients goes beyond just efficiency. We prioritize transparent communication, ensuring our clients are informed about the load being hauled and freight details at every step of the journey. Your peace of mind is our top priority.
          </p>
        </div>

        {/* Third Div - Reliability */}
        <div className="col-md-4 mb-4 text-start">
          <img
            src={`${process.env.PUBLIC_URL}/Reliability.png`}
            alt="Reliability Icon"
            className="img-fluid mb-3"
            style={{ width: '27.25px', height: '27.25px' }}
          />
          <h3 Style={"Color:#045CB4"}>Reliability</h3>
          <p>
            We deeply value the trust that our clients place in us, and we are committed to operating with the utmost integrity. Our mission is to provide the most dependable and efficient truck dispatch service across the United States, ensuring that our clients can always count on us to deliver exceptional results.
          </p>
        </div>
      </div>
    </div>
  );
}

export default ValuesSection;
