import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const NewSection = () => {
  return (
    <div 
      className="new-section-container" 
      style={{
        backgroundImage: `url(${process.env.PUBLIC_URL}/Background.png)`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: '732px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '50px',
      }}
    >
      <div className="container">
        <div className="row align-items-center">
          {/* First Div - Heading, Paragraph, Button */}
          <div className="col-12 col-md-6 text-light p-4">
            <h1 
              className="mb-4" 
              style={{ 
                fontFamily: 'Poppins',
                fontSize: '3.5rem',  // Responsive font size
                fontWeight: '700',
                lineHeight: '1.2',
                textAlign: 'justify',
                color: '#045CB4'
              }}
            >
              The premier truck dispatching service in the United States.
            </h1>
            <p 
              className="mb-4" 
              style={{
                fontFamily: 'Poppins',
                fontSize: '1.2rem',  // Responsive font size
                fontWeight: '400',
                lineHeight: '1.5',
                textAlign: 'left',
                color: '#565656'
              }}
            >
              For years, we've partnered with experts to ensure seamless truck dispatch.
            </p>
            <div className="text-start">
              <button className="btn btn-primary">
                Get in Touch
              </button>
            </div>
          </div>

          {/* Second Div - Image */}
          <div className="col-12 col-md-6 text-center">
            <img
              src={`${process.env.PUBLIC_URL}/Truck.png`}
              alt="Truck Dispatching"
              className="img-fluid"
              style={{
                maxWidth: '100%',
                height: 'auto',
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default NewSection;
