import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const SwiftSection = () => {
  return (
    <div className="container my-5">
      <div className="row d-flex align-items-center">
        {/* First Div - Text Section */}
        <div className="col-md-6">
          <h6>Why Swift?</h6>
          <h1 Style={"Color:#045CB4"} 
          >The Strategic Importance of Hiring a Dispatcher</h1>
          <p>
            Transportation and logistics companies are the backbone of the global economy, ensuring the smooth transit of goods across various sectors. Within this complex ecosystem, dispatchers play a pivotal role, streamlining operations and enhancing efficiency. Here’s why hiring a dispatcher is a crucial decision for businesses looking to thrive in this competitive landscape.
          </p>
        </div>

        {/* Second Div - Image Section */}
        <div className="col-md-6">
          <img
            src={`${process.env.PUBLIC_URL}/Swift.png`}
            alt="Dispatcher Importance"
            className="img-fluid"
          />
        </div>
      </div>
    </div>
  );
};

export default SwiftSection;
