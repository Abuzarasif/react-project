import React from 'react'
import Navbar from './Navbar'
import AboutSection from './About'
import ValuesSection from './ValuesSection'
import SwiftSection from './SwiftSection'
import NewSection from './NewSection'
import OurServices from './OurServices'
import Footer from './Footer'
import FormSection from './FormSection'
import FaqSection from './FaqSection'
import WhatWeDo from './whatWeDo'

const App = () => {
  return (
    <>
    <Navbar/>
     <NewSection/>
     <AboutSection/>
    <ValuesSection/>
    <OurServices/>
    <SwiftSection/>
    <WhatWeDo/>
    <FaqSection/>
    <FormSection/>
    <Footer/> 
    </>
  )
}

export default App