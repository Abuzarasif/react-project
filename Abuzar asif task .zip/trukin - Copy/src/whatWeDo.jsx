import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const WhatWeDo = () => {
  return (
    <div className="container my-5 text-center">
      {/* Section Heading */}
      <h6>WHAT WE DO</h6>
      <h1 className="mb-4" Style={"Color:#045CB4"}>We work with a full range of equipment types</h1>
      <p className="mb-5">
        Transportation and logistics companies are the backbone of the global economy, ensuring the smooth transit of goods across various sectors.
      </p>

      {/* Inner Divs */}
      <div className="row">
        {/* First Inner Div */}
        <div className="col-md-4 mb-4">
          <img
            src={`${process.env.PUBLIC_URL}/Flatbed.png`} // Replace with actual image path
            alt="Equipment 1"
            className="img-fluid mb-2"
          />
          <h4  Style={"Color:#045CB4"}>Flat Bed</h4>
          <p>Our dispatch solutions for flatbed trucking cater to diverse load types, including industrial equipment and oversized structures</p>
        </div>

        {/* Second Inner Div */}
        <div className="col-md-4 mb-4">
          <img
            src={`${process.env.PUBLIC_URL}/Reefer.png`} // Replace with actual image path
            alt="Equipment 2"
            className="img-fluid mb-2"
          />
          <h4 Style={"Color:#045CB4"}>Reefer</h4>
          <p>Reefer trucking is vital for temperature-sensitive goods, with Swift Dispatch Services leading in efficiency and reliability.</p>
        </div>

        {/* Third Inner Div */}
        <div className="col-md-4 mb-4">
          <img
            src={`${process.env.PUBLIC_URL}/DryVan.png`} // Replace with actual image path
            alt="Equipment 3"
            className="img-fluid mb-2"
          />
          <h4 Style={"Color:#045CB4"}>Dry Van</h4>
          <p>Dry van trucking excels in hauling non-perishable goods. Our dispatchers coordinate with brokers, managing cargo details and schedules.</p>
        </div>
      </div>
    </div>
  );
};

export default WhatWeDo;
