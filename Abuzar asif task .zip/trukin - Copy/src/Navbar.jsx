import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Navbar = () => {
  return (
    <div className="d-flex justify-content-center" style={{ width: '100%' }}>
      <div style={{ width: '90%' }}>
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <div className="container-fluid">
            {/* Image at the start */}
            <a className="navbar-brand" href="#">
              <img src={`${process.env.PUBLIC_URL}/logo.png`} alt="Logo" width="130.83" height="49.2" className="d-inline-block align-text-top" />
            </a>

            {/* Centered content */}
            <div className="mx-auto d-flex align-items-center">
              <a className="navbar-brand" href="#">Home</a>

              {/* Toggler for mobile view */}
              <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>

              <div className="collapse navbar-collapse" id="navbarNavDropdown">
                <ul className="navbar-nav mb-2 mb-lg-0">
                  {/* Dropdown */}
                  <li className="nav-item dropdown">
                    <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Services
                    </a>
                    <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                      <li><a className="dropdown-item" href="#">Freight Brokerage</a></li>
                      <li><a className="dropdown-item" href="#">Freight Dispatch</a></li>
                    </ul>
                  </li>

                  {/* Four Names */}
                  <li className="nav-item">
                    <a className="nav-link" href="#">Pricing</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">About us</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">FAQs</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">Contact us</a>
                  </li>
                </ul>
              </div>
            </div>

            {/* Button at the end */}
            <div className="d-flex">
              <button className="btn btn-primary" type="submit">Get in Touch</button>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
}

export default Navbar;
