import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const FaqSection = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const faqs = [
    {
      question: "What service does Swift Dispatch Service provide?",
      answer: "Swift Dispatch Services specializes in truck dispatching, providing efficient services to carriers and owner-operators.",
    },
    {
      question:" What types of trucks does Swift Dispatch Services dispatch?",
      answer: "You can contact us via the contact form on our website or by calling our customer service number.",
    },
    {
      question: "What additional services does Swift Dispatch Service dispatch?",
      answer: "We operate 24/7 to ensure your trucking needs are met at any time.",
    },
    {
      question: "How does Swift Dispatch Services ensure cost-effectiveness for its clients",
      answer: "We maintain strong relationships with top brokers and use advanced technology for load tracking.",
    },
    {
      question: "Are your services available How can I get started with Swift Dispatch Services??",
      answer: "Yes, we provide dispatch services across the entire United States.",
    },
  ];

  const toggleAnswer = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className="container my-5 text-center">
      <h6>FAQs</h6>
      <h1 className="mb-4" Style={"Color:#045CB4"} >Get Answers to Your Questions</h1>

      {faqs.map((faq, index) => (
        <div key={index} className="mb-3">
          <div 
            className="d-flex justify-content-between align-items-center border p-3 rounded" 
            style={{ cursor: 'pointer' }} 
            onClick={() => toggleAnswer(index)}
          >
            <div className="d-flex align-items-center">
              {/* Coma Image at the start */}
              <img
                src={`${process.env.PUBLIC_URL}/Coma.png`} 
                alt="Icon" 
                className="me-2" 
                style={{ width: '9px', height: '9px', opacity: '1' }} // Ensure Coma is visible
              />
              <span>{faq.question}</span>
            </div>
            {/* Caret Image at the end */}
            <img
              src={`${process.env.PUBLIC_URL}/^.png`} 
              alt="Toggle" 
              style={{ 
                width: '9px', 
                height: '9px', 
                transform: activeIndex === index ? 'rotate(-180deg)' : 'rotate(0deg)', // Rotate only on caret click
                transition: 'transform 0.3s ease'  // Smooth transition for rotation
              }} 
            />
          </div>
          {activeIndex === index && (
            <div className="mt-2 p-3 border rounded bg-light">
              {faq.answer}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default FaqSection;
